#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  RH PULSAR — Detection Rule Validation
#  Version: 3.2.3
#  Red Horizon — redhorizon.ph
#
#  Single purpose: verify the 5 detection rules in install.sh
#  are firing correctly against test traffic.
#
#  Usage: sudo bash validate.sh
# ═══════════════════════════════════════════════════════════

set -uo pipefail   # NOT -e — continue past individual rule failures

# ── Colors ──────────────────────────────────────────────────
G='\033[0;32m' R='\033[0;31m' Y='\033[1;33m'
W='\033[1;37m' D='\033[0;37m' N='\033[0m'

# ── State ───────────────────────────────────────────────────
NOTICE_LOG="/opt/zeek/logs/current/notice.log"
SSL_LOG="/opt/zeek/logs/current/ssl.log"
PASS=0; FAIL=0
TS=$(date +%s)
TARGET=""

# ── Helpers ─────────────────────────────────────────────────
ok()   { echo -e "${G}  [✓]${N} $1"; PASS=$((PASS+1)); }
fail() { echo -e "${R}  [✗]${N} $1"; FAIL=$((FAIL+1)); }
warn() { echo -e "${Y}  [!]${N} $1"; }
info() { echo -e "${D}  [→]${N} $1"; }

# ── Banner ──────────────────────────────────────────────────
clear
echo -e "${R}"
echo "  ██████╗ ██╗  ██╗    ██████╗ ██╗   ██╗██╗     ███████╗ █████╗ ██████╗"
echo "  ██╔══██╗██║  ██║    ██╔══██╗██║   ██║██║     ██╔════╝██╔══██╗██╔══██╗"
echo "  ██████╔╝███████║    ██████╔╝██║   ██║██║     ███████╗███████║██████╔╝"
echo "  ██╔══██╗██╔══██║    ██╔═══╝ ██║   ██║██║     ╚════██║██╔══██║██╔══██╗"
echo "  ██║  ██║██║  ██║    ██║     ╚██████╔╝███████╗███████║██║  ██║██║  ██║"
echo "  ╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝      ╚═════╝ ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝"
echo -e "${N}"
echo -e "${W}  Detection Rule Validation — v3.2.3${N}"
echo -e "${D}  Tests the 5 rules deployed by install.sh${N}"
echo ""
echo -e "${R}  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""

# ── Pre-checks ──────────────────────────────────────────────
echo -e "${W}  Pre-checks${N}"
echo ""

[[ $EUID -ne 0 ]] && { echo -e "${R}  Run as root: sudo bash validate.sh${N}"; exit 1; }
ok "Running as root"

if /opt/zeek/bin/zeekctl status 2>/dev/null | grep -q "running"; then
    ok "Zeek: running"
else
    fail "Zeek: not running — run: sudo /opt/zeek/bin/zeekctl deploy"
    exit 1
fi

local_iface=$(grep "^interface=" /opt/zeek/etc/node.cfg 2>/dev/null | cut -d= -f2 || echo "unknown")
ok "Capture interface: ${local_iface}"

# Internet check + target selection
if curl -sf --connect-timeout 3 --max-time 5 http://detectportal.firefox.com > /dev/null 2>&1; then
    ok "Internet: reachable"
    TARGET="http://detectportal.firefox.com"
else
    warn "Internet unreachable — using local gateway"
    GW=$(ip route | awk '/default/{print $3}' | head -1)
    if [[ -z "${GW:-}" ]]; then
        fail "No default gateway found — cannot generate test traffic"
        exit 1
    fi
    TARGET="http://${GW}"
fi

[[ -d /opt/zeek/logs/current ]] || { fail "Zeek logs dir missing"; exit 1; }
ok "Zeek logs dir: present"

# Snapshot notice.log size — only consider new entries
NOTICE_START_LINES=0
[[ -f "$NOTICE_LOG" ]] && NOTICE_START_LINES=$(wc -l < "$NOTICE_LOG" 2>/dev/null || echo 0)
info "Notice log baseline: ${NOTICE_START_LINES} lines"

echo ""
echo -e "${R}  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""
echo -e "${W}  Generating test traffic...${N}"
echo ""

# ── Rule 110001 — C2 Beacon ─────────────────────────────────
info "Testing Rule 110001 — C2 Beacon (6 connections to same host)..."
for i in 1 2 3 4 5 6; do
    curl -s --connect-timeout 3 --max-time 3 "${TARGET}" > /dev/null 2>&1 || true
done
ok "Rule 110001: traffic sent"

# ── Rule 110004 — HTTP C2 Beacon ────────────────────────────
info "Testing Rule 110004 — HTTP C2 Beacon (11 hits same URI)..."
for i in $(seq 1 11); do
    curl -s --connect-timeout 3 --max-time 3 "${TARGET}/beacon-${TS}" > /dev/null 2>&1 || true
done
ok "Rule 110004: traffic sent"

# ── Rule 110005 — Suspicious UA ─────────────────────────────
info "Testing Rule 110005 — Suspicious UA (Havoc, Sliver, meterpreter)..."
curl -s --connect-timeout 3 --max-time 3 -A "Havoc/C2-${TS}"       "${TARGET}/ua-${TS}-1" > /dev/null 2>&1 || true
curl -s --connect-timeout 3 --max-time 3 -A "Sliver/C2-${TS}"      "${TARGET}/ua-${TS}-2" > /dev/null 2>&1 || true
curl -s --connect-timeout 3 --max-time 3 -A "meterpreter/C2-${TS}" "${TARGET}/ua-${TS}-3" > /dev/null 2>&1 || true
ok "Rule 110005: traffic sent"

# ── Rule 110002 — DNS Tunnel ────────────────────────────────
info "Testing Rule 110002 — DNS Tunnel (8 long-subdomain queries)..."
for sub in \
    "aaaaaaaaaaaaaaaaaaaaaaaaaaa" \
    "bbbbbbbbbbbbbbbbbbbbbbbbbbb" \
    "ccccccccccccccccccccccccccc" \
    "ddddddddddddddddddddddddddd" \
    "eeeeeeeeeeeeeeeeeeeeeeeeeee" \
    "fffffffffffffffffffffffffff" \
    "ggggggggggggggggggggggggggg" \
    "hhhhhhhhhhhhhhhhhhhhhhhhhhh"; do
    dig +time=2 +tries=1 "${sub}.dns-${TS}.com" > /dev/null 2>&1 || true
done
ok "Rule 110002: traffic sent"

# ── Rule 110003 — JA4/JA4S ──────────────────────────────────
info "Testing Rule 110003 — JA4/JA4S (TLS fingerprint check)..."
curl -s --connect-timeout 3 --max-time 5 https://google.com > /dev/null 2>&1 || true
curl -s --connect-timeout 3 --max-time 5 https://github.com > /dev/null 2>&1 || true
ok "Rule 110003: TLS traffic sent (fires only on known Sliver fingerprint)"

# ── Wait for Zeek to process — poll instead of hard sleep ───
echo ""
info "Waiting for Zeek to process traffic (up to 15s)..."
NOTICE_NEW=0
for i in $(seq 1 15); do
    sleep 1
    if [[ -f "$NOTICE_LOG" ]]; then
        local_lines=$(wc -l < "$NOTICE_LOG" 2>/dev/null || echo 0)
        NOTICE_NEW=$(( local_lines - NOTICE_START_LINES ))
        if [[ "$NOTICE_NEW" -gt 0 ]]; then
            info "Notices fired after ${i}s (${NOTICE_NEW} new)"
            sleep 2   # let pending notices finish writing
            break
        fi
    fi
    [[ "$i" == "15" ]] && warn "Max wait reached — proceeding"
done

# ── Parse results ───────────────────────────────────────────
echo ""
echo -e "${R}  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""
echo -e "${W}  Detection Results${N}"
echo ""

declare -A RULES=(
    ["C2Beacon::C2_Beacon_Detected"]="110001|C2 Beacon|T1071"
    ["DNSTunnel::DNS_Tunnel_Detected"]="110002|DNS Tunnel|T1071.004"
    ["DetectJA4::Sliver_JA4_Detected"]="110003|Sliver JA4/JA4S|T1573"
    ["HTTPC2::HTTP_C2_Beacon"]="110004|HTTP C2 Beacon|T1071.001"
    ["HTTPC2::Suspicious_UserAgent"]="110005|Suspicious UA|T1071.001"
)

declare -A FIRED

# Single Python pass over notice.log — only new entries since baseline
if [[ -f "$NOTICE_LOG" ]]; then
    while IFS='|' read -r note ts_raw msg; do
        [[ -n "$note" ]] && FIRED["$note"]="${ts_raw}|${msg}"
    done < <(python3 - "$NOTICE_LOG" "$NOTICE_START_LINES" <<'PYEOF'
import sys, json
from datetime import datetime
path = sys.argv[1]
baseline = int(sys.argv[2])
try:
    with open(path) as f:
        for i, line in enumerate(f):
            if i < baseline:
                continue
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            try:
                d = json.loads(line)
                note = d.get('note', '')
                msg  = d.get('msg', '')
                ts   = d.get('ts', 0)
                try:
                    ts_fmt = datetime.fromtimestamp(float(ts)).strftime('%H:%M:%S')
                except Exception:
                    ts_fmt = ''
                if note:
                    print(f"{note}|{ts_fmt}|{msg}")
            except Exception:
                pass
except Exception:
    pass
PYEOF
    )
fi

# Print results
SCORE=0
for note in \
    "C2Beacon::C2_Beacon_Detected" \
    "DNSTunnel::DNS_Tunnel_Detected" \
    "DetectJA4::Sliver_JA4_Detected" \
    "HTTPC2::HTTP_C2_Beacon" \
    "HTTPC2::Suspicious_UserAgent"; do

    IFS='|' read -r rule_id rule_name mitre <<< "${RULES[$note]}"

    if [[ -n "${FIRED[$note]:-}" ]]; then
        IFS='|' read -r fired_ts fired_msg <<< "${FIRED[$note]}"
        echo -e "  ${G}[✓]${N} ${W}Rule ${rule_id}${N} — ${rule_name} — MITRE ${mitre}"
        echo -e "      ${D}Time : ${fired_ts}${N}"
        echo -e "      ${D}Alert: ${fired_msg}${N}"
        SCORE=$((SCORE+1))
    else
        if [[ "$note" == "DetectJA4::Sliver_JA4_Detected" ]]; then
            echo -e "  ${Y}[~]${N} ${W}Rule ${rule_id}${N} — ${rule_name} — MITRE ${mitre}"
            echo -e "      ${D}Pending — requires real Sliver C2 traffic${N}"
            echo -e "      ${D}JA4 engine confirmed working in ssl.log${N}"
        else
            echo -e "  ${R}[✗]${N} ${W}Rule ${rule_id}${N} — ${rule_name} — MITRE ${mitre}"
            echo -e "      ${D}Not fired — check capture interface + traffic flow${N}"
        fi
    fi
    echo ""
done

# ── JA4 fingerprint engine check (proves JA4+ plugin works) ─
echo -e "${W}  JA4 Fingerprint Engine${N}"
echo ""

JA4_COUNT=$(python3 - "$SSL_LOG" <<'PYEOF' 2>/dev/null
import sys, json
path = sys.argv[1]
count = 0
try:
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            try:
                d = json.loads(line)
                if d.get('ja4') or d.get('ja4s'):
                    count += 1
            except Exception:
                pass
except Exception:
    pass
print(count)
PYEOF
)
JA4_COUNT=${JA4_COUNT:-0}

if [[ "$JA4_COUNT" -gt 0 ]]; then
    ok "JA4/JA4S fingerprints captured: ${JA4_COUNT} TLS sessions"
else
    warn "No JA4 fingerprints yet — generate HTTPS traffic and re-run"
fi

# ── Summary ─────────────────────────────────────────────────
echo ""
echo -e "${R}  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""
echo -e "  ${W}Interface  :${N} ${local_iface}"
echo -e "  ${W}Zeek       :${N} $(/opt/zeek/bin/zeek --version 2>&1 | grep -oP '\d+\.\d+\.\d+' | head -1 || echo 'unknown')"
echo -e "  ${W}Timestamp  :${N} $(date '+%Y-%m-%d %H:%M:%S')"
echo ""

if [[ "$SCORE" -ge 4 ]]; then
    echo -e "  ${G}Score: ${SCORE}/5 rules validated ✓${N}"
    echo -e "  ${G}RH Pulsar detection engine is operational.${N}"
elif [[ "$SCORE" -ge 2 ]]; then
    echo -e "  ${Y}Score: ${SCORE}/5 rules validated${N}"
    echo -e "  ${Y}Partial — check capture interface and traffic routing.${N}"
else
    echo -e "  ${R}Score: ${SCORE}/5 rules validated${N}"
    echo -e "  ${R}Likely cause: capture interface is not seeing the test traffic.${N}"
    echo -e "  ${R}Check: ip route get 8.8.8.8 → matches /opt/zeek/etc/node.cfg interface${N}"
fi

echo ""
echo -e "${R}  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""
