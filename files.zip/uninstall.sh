#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  RH PULSAR — Sensor Uninstaller
#  Version: 1.0.0
#  Red Horizon — redhorizon.ph
#
#  Purpose:
#    Cleanly removes RH Pulsar sensor components from a host.
#    Reverses the changes made by install.sh.
#
#  What it removes:
#    - Zeek + JA4+ (system packages)
#    - RH Pulsar Zeek scripts (/opt/zeek/share/zeek/site/)
#    - SIEM forwarder (wazuh-agent, filebeat, splunk, etc.)
#    - JA4 threat intel updater (systemd timer + service)
#    - All RH Pulsar config (/etc/rh-pulsar/, /opt/rh-pulsar/)
#    - Active response script
#    - Log files (optional, prompts)
#
#  What it keeps (unless --purge-all):
#    - Network interface configuration (mgmt + capture)
#    - SSH keys
#    - System user accounts
#    - Backup of removed configs at /var/backups/rh-pulsar-uninstall-<ts>/
#
#  Usage:
#    sudo bash uninstall.sh              # Interactive, asks before deleting
#    sudo bash uninstall.sh --yes        # No prompts, assume yes
#    sudo bash uninstall.sh --keep-zeek  # Keep Zeek installed (just remove RH Pulsar bits)
#    sudo bash uninstall.sh --dry-run    # Show what would be removed, don't actually do it
#    sudo bash uninstall.sh --purge-all  # Also remove logs, backups, all traces
# ═══════════════════════════════════════════════════════════

set -uo pipefail

# ── Versions ────────────────────────────────────────────────
UNINSTALL_VER="1.0.0"

# ── Args ────────────────────────────────────────────────────
ASSUME_YES=false
KEEP_ZEEK=false
DRY_RUN=false
PURGE_ALL=false

while [[ $# -gt 0 ]]; do
    case "${1:-}" in
        --yes|-y)        ASSUME_YES=true ;;
        --keep-zeek)     KEEP_ZEEK=true ;;
        --dry-run)       DRY_RUN=true ;;
        --purge-all)     PURGE_ALL=true ;;
        --help|-h)       sed -n '2,32p' "$0"; exit 0 ;;
        *)               echo "Unknown argument: $1"; exit 1 ;;
    esac
    shift
done

# ── Colors ──────────────────────────────────────────────────
R='\033[0;31m' G='\033[0;32m' Y='\033[1;33m' W='\033[1;37m' D='\033[0;37m' N='\033[0m'

# ── State ───────────────────────────────────────────────────
LOG="/var/log/rh-pulsar-uninstall.log"
BACKUP_DIR="/var/backups/rh-pulsar-uninstall-$(date +%Y%m%d-%H%M%S)"
REMOVED=0; KEPT=0; FAILED=0

# ── Helpers ─────────────────────────────────────────────────
ts()   { date '+%Y-%m-%d %H:%M:%S'; }
ok()   { echo -e "${G}  [✓]${N} $1"; echo "[$(ts)] OK   $1" >> "$LOG" 2>/dev/null; REMOVED=$((REMOVED+1)); }
keep() { echo -e "${D}  [-]${N} $1"; echo "[$(ts)] KEEP $1" >> "$LOG" 2>/dev/null; KEPT=$((KEPT+1)); }
fail() { echo -e "${R}  [✗]${N} $1"; echo "[$(ts)] FAIL $1" >> "$LOG" 2>/dev/null; FAILED=$((FAILED+1)); }
warn() { echo -e "${Y}  [!]${N} $1"; echo "[$(ts)] WARN $1" >> "$LOG" 2>/dev/null; }
info() { echo -e "${D}  [→]${N} $1"; }
die()  { echo -e "\n${R}  ✗ FATAL: $1${N}\n"; exit 1; }

# Prompt before destructive action
confirm() {
    local prompt="$1"
    [[ "$ASSUME_YES" == "true" ]] && return 0
    read -rp "  $prompt (y/N): " ans || ans=N
    [[ "${ans:-N}" == "y" || "${ans:-N}" == "Y" ]]
}

# Safe remove (respects --dry-run)
safe_rm() {
    local target="$1"
    local desc="${2:-$target}"
    if [[ ! -e "$target" && ! -L "$target" ]]; then
        keep "$desc (not present)"
        return 0
    fi
    if [[ "$DRY_RUN" == "true" ]]; then
        ok "WOULD REMOVE: $desc"
        return 0
    fi
    if rm -rf "$target" 2>>"$LOG"; then
        ok "Removed: $desc"
    else
        fail "Could not remove: $desc"
    fi
}

# Safe service stop+disable
safe_disable_service() {
    local svc="$1"
    if ! systemctl list-unit-files 2>/dev/null | grep -q "^${svc}"; then
        keep "Service ${svc} (not installed)"
        return 0
    fi
    if [[ "$DRY_RUN" == "true" ]]; then
        ok "WOULD STOP+DISABLE: $svc"
        return 0
    fi
    systemctl stop "$svc" 2>/dev/null || true
    systemctl disable "$svc" 2>/dev/null || true
    ok "Stopped + disabled: $svc"
}

# Safe apt remove
safe_apt_remove() {
    local pkg="$1"
    if ! dpkg -l "$pkg" 2>/dev/null | grep -q "^ii"; then
        keep "Package ${pkg} (not installed)"
        return 0
    fi
    if [[ "$DRY_RUN" == "true" ]]; then
        ok "WOULD REMOVE PACKAGE: $pkg"
        return 0
    fi
    if DEBIAN_FRONTEND=noninteractive apt-get remove -y -qq "$pkg" >>"$LOG" 2>&1; then
        ok "Removed package: $pkg"
    else
        fail "Could not remove package: $pkg"
    fi
}

# ── Banner ──────────────────────────────────────────────────
clear
echo -e "${R}"
echo "  ██████╗ ██╗  ██╗    ██████╗ ██╗   ██╗██╗     ███████╗ █████╗ ██████╗"
echo "  ██╔══██╗██║  ██║    ██╔══██╗██║   ██║██║     ██╔════╝██╔══██╗██╔══██╗"
echo "  ██████╔╝███████║    ██████╔╝██║   ██║██║     ███████╗███████║██████╔╝"
echo "  ██╔══██╗██╔══██║    ██╔═══╝ ██║   ██║██║     ╚════██║██╔══██║██╔══██╗"
echo "  ██║  ██║██║  ██║    ██║     ╚██████╔╝███████╗███████║██║  ██║██║  ██║"
echo "  ╚═╝  ╚═╝╚═╝  ╚═╝    ╚═╝      ╚═════╝ ╚══════╝╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝"
echo -e "${N}"
echo -e "${W}  Sensor Uninstaller — v${UNINSTALL_VER}${N}"
echo -e "${D}  Removes RH Pulsar sensor components from this host${N}"
[[ "$DRY_RUN" == "true" ]] && echo -e "\n${Y}  [ DRY RUN — no changes will be made ]${N}"
[[ "$KEEP_ZEEK" == "true" ]] && echo -e "\n${Y}  [ --keep-zeek: Zeek will not be removed ]${N}"
[[ "$PURGE_ALL" == "true" ]] && echo -e "\n${Y}  [ --purge-all: logs and backups will also be removed ]${N}"
echo ""

# ── Preflight ──────────────────────────────────────────────
[[ $EUID -ne 0 ]] && die "Run as root: sudo bash $0"

mkdir -p "$(dirname "$LOG")"
[[ "$DRY_RUN" == "true" ]] || : > "$LOG"
echo "[$(ts)] RH Pulsar Uninstaller v${UNINSTALL_VER} started" >> "$LOG" 2>/dev/null

# Detect installed components
SENSOR_NAME=$(cat /etc/rh-pulsar/name 2>/dev/null || echo "(unknown)")
SIEM_NAME=$(cat /etc/rh-pulsar/siem 2>/dev/null || echo "(unknown)")
SENSOR_ID=$(cat /etc/rh-pulsar/sensor_id 2>/dev/null || echo "(unknown)")

if [[ ! -d /etc/rh-pulsar ]] && [[ ! -d /opt/zeek ]] && [[ ! -d /opt/rh-pulsar ]]; then
    warn "No RH Pulsar installation detected on this host"
    if ! confirm "Continue anyway?"; then
        echo "  Aborted."
        exit 0
    fi
fi

echo -e "${W}  Detected installation:${N}"
echo -e "    Sensor name : ${SENSOR_NAME}"
echo -e "    Sensor ID   : ${SENSOR_ID}"
echo -e "    SIEM mode   : ${SIEM_NAME}"
echo ""

# Final confirmation
if [[ "$DRY_RUN" != "true" ]]; then
    echo -e "${R}  This will remove RH Pulsar sensor components from this host.${N}"
    echo -e "${R}  A backup of configs will be saved to: ${BACKUP_DIR}${N}"
    if ! confirm "Proceed with uninstall?"; then
        echo "  Aborted."
        exit 0
    fi
fi

echo ""

# ── Phase 1 — Backup configs ───────────────────────────────
echo -e "${W}  Phase 1: Backing up configs${N}"
if [[ "$DRY_RUN" != "true" ]]; then
    mkdir -p "$BACKUP_DIR"
    [[ -d /etc/rh-pulsar ]]                && cp -a /etc/rh-pulsar              "$BACKUP_DIR/" 2>>"$LOG" || true
    [[ -f /opt/zeek/etc/node.cfg ]]        && cp -a /opt/zeek/etc               "$BACKUP_DIR/zeek-etc" 2>>"$LOG" || true
    [[ -d /opt/zeek/share/zeek/site ]]     && cp -a /opt/zeek/share/zeek/site   "$BACKUP_DIR/zeek-site" 2>>"$LOG" || true
    [[ -f /var/ossec/etc/ossec.conf ]]     && cp -a /var/ossec/etc/ossec.conf   "$BACKUP_DIR/ossec.conf" 2>>"$LOG" || true
    ok "Configs backed up to ${BACKUP_DIR}"
else
    ok "WOULD BACKUP configs to: ${BACKUP_DIR}"
fi
echo ""

# ── Phase 2 — Stop services ────────────────────────────────
echo -e "${W}  Phase 2: Stopping services${N}"

# Zeek (only if not keeping)
if [[ "$KEEP_ZEEK" != "true" ]] && [[ -x /opt/zeek/bin/zeekctl ]]; then
    if [[ "$DRY_RUN" != "true" ]]; then
        /opt/zeek/bin/zeekctl stop >>"$LOG" 2>&1 || true
        ok "Zeek stopped"
    else
        ok "WOULD STOP: Zeek"
    fi
fi

# JA4 threat intel updater
safe_disable_service "rh-pulsar-ja4-update.timer"
safe_disable_service "rh-pulsar-ja4-update.service"

# SIEM forwarders — stop whichever is running
safe_disable_service "wazuh-agent"
safe_disable_service "filebeat"
safe_disable_service "SplunkForwarder"
safe_disable_service "syslog-ng"

echo ""

# ── Phase 3 — Remove SIEM forwarder ────────────────────────
echo -e "${W}  Phase 3: Removing SIEM forwarder${N}"

case "$SIEM_NAME" in
    *Wazuh*|*wazuh*)
        safe_apt_remove "wazuh-agent"
        safe_rm "/var/ossec" "Wazuh agent directory"
        ;;
    *Elastic*|*elastic*)
        safe_apt_remove "filebeat"
        safe_rm "/etc/filebeat" "Filebeat config"
        safe_rm "/var/lib/filebeat" "Filebeat state"
        ;;
    *Splunk*|*splunk*)
        if [[ "$DRY_RUN" != "true" ]]; then
            /opt/splunkforwarder/bin/splunk stop 2>>"$LOG" || true
            /opt/splunkforwarder/bin/splunk disable boot-start 2>>"$LOG" || true
        fi
        safe_rm "/opt/splunkforwarder" "Splunk Forwarder"
        ;;
    *Sentinel*|*sentinel*|*QRadar*|*qradar*|*Syslog*|*syslog*)
        # Rsyslog-based — just remove our config snippet
        safe_rm "/etc/rsyslog.d/49-rh-pulsar.conf" "RH Pulsar rsyslog config"
        if [[ "$DRY_RUN" != "true" ]]; then
            systemctl restart rsyslog 2>/dev/null || true
        fi
        ;;
    *)
        keep "SIEM forwarder: unknown SIEM mode, skipping"
        ;;
esac

echo ""

# ── Phase 4 — Remove Zeek + JA4+ ───────────────────────────
echo -e "${W}  Phase 4: Removing Zeek + JA4+${N}"

if [[ "$KEEP_ZEEK" == "true" ]]; then
    keep "Zeek (kept due to --keep-zeek)"
    keep "JA4+ plugin (kept due to --keep-zeek)"
else
    # Remove Zeek package
    if dpkg -l zeek 2>/dev/null | grep -q "^ii"; then
        safe_apt_remove "zeek"
    elif [[ -d /opt/zeek ]]; then
        info "Zeek not installed via apt, removing /opt/zeek directly"
    fi
    safe_rm "/opt/zeek" "Zeek installation directory"

    # Remove Zeek repo
    safe_rm "/etc/apt/sources.list.d/security:zeek.list" "Zeek apt source"
    safe_rm "/etc/apt/trusted.gpg.d/security_zeek.gpg" "Zeek repo key"
fi

echo ""

# ── Phase 5 — Remove RH Pulsar config + scripts ────────────
echo -e "${W}  Phase 5: Removing RH Pulsar artifacts${N}"

# Systemd units
safe_rm "/etc/systemd/system/rh-pulsar-ja4-update.service" "JA4 updater service unit"
safe_rm "/etc/systemd/system/rh-pulsar-ja4-update.timer" "JA4 updater timer unit"
if [[ "$DRY_RUN" != "true" ]]; then
    systemctl daemon-reload 2>/dev/null || true
fi

# Updater script
safe_rm "/usr/local/sbin/rh-pulsar-ja4-update.sh" "JA4 updater script"

# Config + state directories
safe_rm "/etc/rh-pulsar" "RH Pulsar config directory"
safe_rm "/opt/rh-pulsar" "RH Pulsar scripts directory"
safe_rm "/var/lib/rh-pulsar" "RH Pulsar state directory"

# AR script (if deployed on sensor)
safe_rm "/var/ossec/active-response/bin/rh-pulsar-block.sh" "Active Response script (if any)"

echo ""

# ── Phase 6 — Logs (optional) ──────────────────────────────
echo -e "${W}  Phase 6: Logs${N}"

if [[ "$PURGE_ALL" == "true" ]]; then
    safe_rm "/var/log/rh-pulsar-ar.log" "AR log"
    safe_rm "/var/log/rh-pulsar-install.log" "Install log"
    safe_rm "$BACKUP_DIR" "Config backup (--purge-all)"
else
    keep "/var/log/rh-pulsar-ar.log (use --purge-all to remove)"
    keep "/var/log/rh-pulsar-install.log (use --purge-all to remove)"
    keep "$BACKUP_DIR (config backup, retain for safety)"
fi

echo ""

# ── Phase 7 — Network interface restoration ────────────────
echo -e "${W}  Phase 7: Network interface state${N}"
info "Capture interface was set to promiscuous mode during install"
info "To restore normal state, reboot or run:"
info "  sudo ip link set <iface> promisc off"
keep "Network interfaces (manual restoration required)"

echo ""

# ── Summary ─────────────────────────────────────────────────
echo -e "${R}  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""

if [[ "$DRY_RUN" == "true" ]]; then
    echo -e "${Y}  DRY RUN COMPLETE — no changes were made${N}"
else
    echo -e "${G}  RH PULSAR SENSOR UNINSTALLED${N}"
fi

echo ""
echo -e "  ${W}Items removed${N}: ${REMOVED}"
echo -e "  ${W}Items kept   ${N}: ${KEPT}"
echo -e "  ${W}Failures     ${N}: ${FAILED}"
echo -e "  ${W}Log file     ${N}: ${LOG}"
[[ "$DRY_RUN" != "true" ]] && [[ "$PURGE_ALL" != "true" ]] && \
    echo -e "  ${W}Config backup${N}: ${BACKUP_DIR}"

echo ""
if [[ "$DRY_RUN" != "true" ]] && [[ "$FAILED" -eq 0 ]]; then
    echo -e "${G}  ✓ Cleanup successful${N}"
    echo ""
    echo -e "${D}  To remove backups later: sudo rm -rf ${BACKUP_DIR}${N}"
fi
echo ""
echo -e "${W}  Red Horizon — redhorizon.ph${N}"
echo ""
