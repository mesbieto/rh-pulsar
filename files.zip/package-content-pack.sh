#!/bin/bash
# ═══════════════════════════════════════════════════════════
#  RH PULSAR — Content Pack Builder
#  Version: 1.0.0
#  Red Horizon — redhorizon.ph
#
#  Purpose:
#    Builds the rh-pulsar-wazuh-content-vX.Y.tgz tarball that
#    client SIEM engineers install into their existing Wazuh
#    Manager. This is the deliverable referenced in the
#    "RH Pulsar for Wazuh — Integration Guide" document.
#
#  When to run:
#    - At product release time (Red Horizon engineering)
#    - When updating decoder, rules, or AR script content
#    - To produce a new version for client distribution
#
#  Output:
#    ./dist/rh-pulsar-wazuh-content-vX.Y.tgz
#    ./dist/rh-pulsar-wazuh-content-vX.Y.sha256
#
#  Usage:
#    bash package-content-pack.sh           # Build current version
#    bash package-content-pack.sh --check   # Validate output XML files
# ═══════════════════════════════════════════════════════════

set -euo pipefail

# ── Versions ────────────────────────────────────────────────
CONTENT_PACK_VER="1.0.0"
PRODUCT_VER="3.2.3"        # Matches install.sh PULSAR_VER
WAZUH_TARGET="4.x"

# ── Args ────────────────────────────────────────────────────
CHECK_ONLY=false
case "${1:-}" in
    --check) CHECK_ONLY=true ;;
    --help|-h) sed -n '2,28p' "$0"; exit 0 ;;
    "") : ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
esac

# ── Colors ──────────────────────────────────────────────────
G='\033[0;32m' R='\033[0;31m' Y='\033[1;33m' W='\033[1;37m' N='\033[0m'

ok()   { echo -e "${G}  [✓]${N} $1"; }
fail() { echo -e "${R}  [✗]${N} $1"; }
info() { echo -e "      $1"; }

# ── Paths ───────────────────────────────────────────────────
WORK_ROOT="./build-content-pack-$$"
PACK_NAME="rh-pulsar-wazuh-content"
PACK_DIR="${WORK_ROOT}/${PACK_NAME}"
DIST_DIR="./dist"
TGZ_OUT="${DIST_DIR}/${PACK_NAME}-v${CONTENT_PACK_VER}.tgz"
SHA_OUT="${DIST_DIR}/${PACK_NAME}-v${CONTENT_PACK_VER}.sha256"

# Cleanup on exit
cleanup() { rm -rf "$WORK_ROOT" 2>/dev/null || true; }
trap cleanup EXIT

# ── Banner ──────────────────────────────────────────────────
echo ""
echo -e "${W}  RH Pulsar Content Pack Builder${N}"
echo "  ─────────────────────────────────────────────"
echo -e "  Content pack version : ${W}${CONTENT_PACK_VER}${N}"
echo -e "  Sensor product version: ${W}${PRODUCT_VER}${N}"
echo -e "  Wazuh target         : ${W}${WAZUH_TARGET}${N}"
echo ""

# Create dir structure
mkdir -p "${PACK_DIR}/decoders"
mkdir -p "${PACK_DIR}/rules"
mkdir -p "${PACK_DIR}/active-response"
mkdir -p "${PACK_DIR}/examples"
mkdir -p "${DIST_DIR}"

# ═══════════════════════════════════════════════════════════
# DECODER — rh-pulsar-decoders.xml
# ═══════════════════════════════════════════════════════════
cat > "${PACK_DIR}/decoders/rh-pulsar-decoders.xml" << 'EOF'
<!--
  RH Pulsar — Wazuh Decoders for Zeek notice.log
  Version: 1.0.0
  Target:  Wazuh Manager 4.x

  Description:
    Parses JSON notices emitted by RH Pulsar sensors. The sensor's
    Wazuh Agent ships notice.log entries with a "rh-pulsar-zeek" label
    (configured in /var/ossec/etc/ossec.conf on the sensor side).

    The prematch matches on the literal "rh-pulsar-zeek" string that
    appears in each shipped log line. The fields decoder extracts
    standard JSON fields: ts, note, msg, src, dst, identifier, ja4, ja4s.

  Do not modify this file directly. Customizations belong in
  /var/ossec/etc/decoders/local_decoder.xml
-->

<decoder name="rh-pulsar-zeek">
  <prematch>"rh-pulsar-zeek"</prematch>
</decoder>

<decoder name="rh-pulsar-zeek-fields">
  <parent>rh-pulsar-zeek</parent>
  <plugin_decoder>JSON_Decoder</plugin_decoder>
</decoder>
EOF
ok "Decoder: rh-pulsar-decoders.xml"

# ═══════════════════════════════════════════════════════════
# RULES — rh-pulsar-rules.xml
# ═══════════════════════════════════════════════════════════
cat > "${PACK_DIR}/rules/rh-pulsar-rules.xml" << 'EOF'
<!--
  RH Pulsar — Wazuh Rules
  Version: 1.0.0
  Target:  Wazuh Manager 4.x

  Description:
    Maps RH Pulsar Zeek notice types to Wazuh alerts with severity
    levels and MITRE ATT&CK technique mappings. Rule IDs 110000-110013
    are reserved for RH Pulsar content.

  Rule severity guide:
    Level 10 — Suspicious but high false-positive potential
    Level 12 — Likely malicious, investigate immediately
    Level 14 — Strong evidence of malicious activity
    Level 15 — Critical, automatic active response triggered

  Customization:
    Do NOT modify this file directly. Place overrides in
    /var/ossec/etc/rules/local_rules.xml using <overwrite>yes</overwrite>
    if you need to change rule levels or descriptions, or write
    sibling rules with higher <if_sid> precedence to extend logic.
-->

<group name="rh-pulsar,ndr,">

  <!-- Base rule — fires on any RH Pulsar Zeek notice received -->
  <rule id="110000" level="3">
    <decoded_as>rh-pulsar-zeek</decoded_as>
    <description>RH Pulsar: Zeek notice received</description>
    <group>rh-pulsar,zeek,</group>
  </rule>

  <!-- Rule 110001 — C2 Beacon (T1071) -->
  <rule id="110001" level="12">
    <if_sid>110000</if_sid>
    <field name="note">C2Beacon::C2_Beacon_Detected</field>
    <description>RH Pulsar 110001: C2 Beacon detected - repeated outbound connections</description>
    <mitre>
      <id>T1071</id>
    </mitre>
    <group>rh-pulsar,c2,beacon,attack.command_and_control,</group>
  </rule>

  <!-- Rule 110002 — DNS Tunnel (T1071.004) -->
  <rule id="110002" level="14">
    <if_sid>110000</if_sid>
    <field name="note">DNSTunnel::DNS_Tunnel_Detected</field>
    <description>RH Pulsar 110002: DNS Tunnel detected - possible data exfiltration via DNS</description>
    <mitre>
      <id>T1071.004</id>
    </mitre>
    <group>rh-pulsar,dns,tunnel,exfiltration,attack.command_and_control,</group>
  </rule>

  <!-- Rule 110003 — Sliver JA4 (T1573) — TRIGGERS ACTIVE RESPONSE -->
  <rule id="110003" level="15">
    <if_sid>110000</if_sid>
    <field name="note">DetectJA4::Sliver_JA4_Detected</field>
    <description>RH Pulsar 110003: Sliver C2 framework detected via JA4 fingerprint</description>
    <mitre>
      <id>T1573</id>
    </mitre>
    <group>rh-pulsar,ja4,sliver,c2,attack.command_and_control,</group>
  </rule>

  <!-- Rule 110013 — Malicious JA4 from threat intel DB (T1573) -->
  <rule id="110013" level="14">
    <if_sid>110000</if_sid>
    <field name="note">DetectJA4::Malicious_JA4_Detected</field>
    <description>RH Pulsar 110013: Malicious JA4 fingerprint detected from intel DB</description>
    <mitre>
      <id>T1573</id>
    </mitre>
    <group>rh-pulsar,ja4,c2,attack.command_and_control,</group>
  </rule>

  <!-- Rule 110004 — HTTP C2 Beacon (T1071.001) -->
  <rule id="110004" level="12">
    <if_sid>110000</if_sid>
    <field name="note">HTTPC2::HTTP_C2_Beacon</field>
    <description>RH Pulsar 110004: HTTP C2 Beacon detected - repeated hits to same URI</description>
    <mitre>
      <id>T1071.001</id>
    </mitre>
    <group>rh-pulsar,http,c2,beacon,attack.command_and_control,</group>
  </rule>

  <!-- Rule 110005 — Suspicious User-Agent (T1071.001) -->
  <!-- NOTE: This rule has ~71% false positive rate in DevOps-heavy environments.
       Consider tuning or disabling per the Integration Guide. -->
  <rule id="110005" level="10">
    <if_sid>110000</if_sid>
    <field name="note">HTTPC2::Suspicious_UserAgent</field>
    <description>RH Pulsar 110005: Suspicious User-Agent - possible C2 client</description>
    <mitre>
      <id>T1071.001</id>
    </mitre>
    <group>rh-pulsar,http,suspicious_ua,attack.command_and_control,</group>
  </rule>

  <!-- Rule 110006 — Novel JA4 from Tier 2 baseline (T1573) -->
  <rule id="110006" level="10">
    <if_sid>110000</if_sid>
    <field name="note">JA4Baseline::Novel_JA4_Observed</field>
    <description>RH Pulsar 110006: Novel JA4 fingerprint - anomaly vs environment baseline</description>
    <mitre>
      <id>T1573</id>
    </mitre>
    <group>rh-pulsar,ja4,anomaly,baseline,</group>
  </rule>

</group>
EOF
ok "Rules:   rh-pulsar-rules.xml"

# ═══════════════════════════════════════════════════════════
# ACTIVE RESPONSE — rh-pulsar-block.sh
# ═══════════════════════════════════════════════════════════
cat > "${PACK_DIR}/active-response/rh-pulsar-block.sh" << 'AREOF'
#!/bin/bash
# RH Pulsar — Active Response: Auto-isolate Source IP
# Version: 1.0.0
#
# Deployment:
#   This script must be deployed to each SENSOR (not the manager).
#   Path:    /var/ossec/active-response/bin/rh-pulsar-block.sh
#   Owner:   root:wazuh
#   Mode:    750
#
# Triggered by:
#   Wazuh Manager when Rule 110003 (Sliver JA4) fires.
#   Manager sends 'add' command, then 'delete' after AR_TIMEOUT.
#
# Action:
#   iptables DROP on the source IP for AR_TIMEOUT seconds.
#
# Log:
#   /var/log/rh-pulsar-ar.log

LOG="/var/log/rh-pulsar-ar.log"
ACTION="${1:-add}"
USER="${2:-}"
SRCIP="${3:-}"

# Source per-sensor config if exists
[[ -f /etc/rh-pulsar/manager.conf ]] && . /etc/rh-pulsar/manager.conf
AR_TIMEOUT="${AR_TIMEOUT:-3600}"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG"
}

# Sanity check IP
if [[ ! "$SRCIP" =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
    log "ERROR: Invalid source IP: '$SRCIP'"
    exit 1
fi

# Don't block private/local ranges we shouldn't (safety net)
case "$SRCIP" in
    127.*|0.0.0.0|169.254.*)
        log "REFUSED: Will not block local/link-local IP: $SRCIP"
        exit 1 ;;
esac

case "$ACTION" in
    add)
        log "BLOCK: Adding iptables DROP for $SRCIP (timeout ${AR_TIMEOUT}s)"
        iptables -I INPUT   -s "$SRCIP" -j DROP -m comment --comment "rh-pulsar-block" 2>/dev/null
        iptables -I FORWARD -s "$SRCIP" -j DROP -m comment --comment "rh-pulsar-block" 2>/dev/null
        ;;
    delete)
        log "UNBLOCK: Removing iptables DROP for $SRCIP"
        iptables -D INPUT   -s "$SRCIP" -j DROP -m comment --comment "rh-pulsar-block" 2>/dev/null || true
        iptables -D FORWARD -s "$SRCIP" -j DROP -m comment --comment "rh-pulsar-block" 2>/dev/null || true
        ;;
    *)
        log "ERROR: Unknown action: $ACTION"
        exit 1 ;;
esac

exit 0
AREOF
chmod 755 "${PACK_DIR}/active-response/rh-pulsar-block.sh"
ok "AR script: rh-pulsar-block.sh"

# ═══════════════════════════════════════════════════════════
# EXAMPLES — sample-notice.log
# ═══════════════════════════════════════════════════════════
cat > "${PACK_DIR}/examples/sample-notice.log" << 'EOF'
{"ts":1748263818.422,"note":"C2Beacon::C2_Beacon_Detected","msg":"C2 Beacon: 192.168.1.50 -> 142.93.x.x (6 connections in 5min)","src":"192.168.1.50","src_port":48330,"dst":"142.93.x.x","dst_port":443,"identifier":"c2beacon-192.168.1.50-142.93.x.x","peer_descr":"worker-1"}
{"ts":1748263845.118,"note":"DNSTunnel::DNS_Tunnel_Detected","msg":"DNS Tunnel suspected: 10.0.5.18 - 6 long-subdomain queries in 5min","src":"10.0.5.18","dst":"8.8.8.8","identifier":"dnstunnel-10.0.5.18","peer_descr":"worker-1"}
{"ts":1748263892.701,"note":"DetectJA4::Sliver_JA4_Detected","msg":"Sliver C2 framework detected via JA4 fingerprint","src":"192.168.5.42","src_port":48512,"dst":"142.93.x.x","dst_port":443,"ja4":"t13d190900_9dc949149365_97f8aa674fd9","ja4s":"t130200_1301_a56c5b993250","identifier":"ja4-sliver-192.168.5.42-142.93.x.x","peer_descr":"worker-1"}
{"ts":1748263921.045,"note":"HTTPC2::HTTP_C2_Beacon","msg":"HTTP C2 Beacon: 192.168.1.50 -> example.com/beacon-1748263 (11 hits)","src":"192.168.1.50","dst":"93.184.x.x","identifier":"httpc2-beacon-192.168.1.50-example.com","peer_descr":"worker-1"}
{"ts":1748263935.812,"note":"HTTPC2::Suspicious_UserAgent","msg":"Suspicious UA: 'Sliver/C2-1748263' from 172.16.2.7","src":"172.16.2.7","dst":"93.184.x.x","identifier":"suspicious-ua-172.16.2.7","peer_descr":"worker-1"}
EOF
ok "Example: sample-notice.log"

# ═══════════════════════════════════════════════════════════
# EXAMPLES — sample-alert.json (what Wazuh produces)
# ═══════════════════════════════════════════════════════════
cat > "${PACK_DIR}/examples/sample-alert.json" << 'EOF'
{
  "timestamp": "2026-05-26T14:34:18.422Z",
  "rule": {
    "level": 15,
    "description": "RH Pulsar 110003: Sliver C2 framework detected via JA4 fingerprint",
    "id": "110003",
    "mitre": {
      "id": ["T1573"],
      "tactic": ["Command and Control"],
      "technique": ["Encrypted Channel"]
    },
    "firedtimes": 1,
    "mail": true,
    "groups": [
      "rh-pulsar",
      "ja4",
      "sliver",
      "c2",
      "attack.command_and_control"
    ]
  },
  "agent": {
    "id": "001",
    "name": "RHP-LAB01",
    "ip": "192.168.112.30"
  },
  "manager": {
    "name": "wazuh-manager"
  },
  "id": "1748263892.123456",
  "decoder": {
    "name": "rh-pulsar-zeek-fields",
    "parent": "rh-pulsar-zeek"
  },
  "data": {
    "ts": "1748263892.701",
    "note": "DetectJA4::Sliver_JA4_Detected",
    "msg": "Sliver C2 framework detected via JA4 fingerprint",
    "src": "192.168.5.42",
    "src_port": "48512",
    "dst": "142.93.x.x",
    "dst_port": "443",
    "ja4": "t13d190900_9dc949149365_97f8aa674fd9",
    "ja4s": "t130200_1301_a56c5b993250",
    "identifier": "ja4-sliver-192.168.5.42-142.93.x.x",
    "rh-pulsar-zeek": "notice"
  },
  "location": "/opt/zeek/logs/current/notice.log"
}
EOF
ok "Example: sample-alert.json"

# ═══════════════════════════════════════════════════════════
# INSTALL.md
# ═══════════════════════════════════════════════════════════
cat > "${PACK_DIR}/INSTALL.md" << EOF
# RH Pulsar for Wazuh — Quick Install

**Content pack version:** ${CONTENT_PACK_VER}
**Sensor product version:** ${PRODUCT_VER}
**Wazuh target:** ${WAZUH_TARGET}

For the complete integration guide with tuning, troubleshooting, and FAQ, see:
**RH Pulsar for Wazuh — Integration Guide** (PDF, shipped separately).

---

## Prerequisites

Before installing, confirm:

- [ ] Wazuh Manager 4.x is running
- [ ] You have root or sudo access on the manager host
- [ ] RH Pulsar sensor is deployed and shipping logs to this manager
- [ ] Sensor's Wazuh Agent shows as Active in your dashboard

## Quick installation (5 steps, ~15 minutes)

### Step 1 — Extract the content pack

\`\`\`bash
tar -xzf rh-pulsar-wazuh-content-v${CONTENT_PACK_VER}.tgz
cd rh-pulsar-wazuh-content/
\`\`\`

### Step 2 — Install the decoder

\`\`\`bash
sudo cp decoders/rh-pulsar-decoders.xml /var/ossec/etc/decoders/
sudo chown root:wazuh /var/ossec/etc/decoders/rh-pulsar-decoders.xml
sudo chmod 640        /var/ossec/etc/decoders/rh-pulsar-decoders.xml
\`\`\`

### Step 3 — Install the rules

\`\`\`bash
sudo cp rules/rh-pulsar-rules.xml /var/ossec/etc/rules/
sudo chown root:wazuh /var/ossec/etc/rules/rh-pulsar-rules.xml
sudo chmod 640        /var/ossec/etc/rules/rh-pulsar-rules.xml
\`\`\`

### Step 4 — Validate configuration

\`\`\`bash
sudo /var/ossec/bin/wazuh-logtest -t
\`\`\`

Should print "Configuration is correct" and list the 7 new rules.

### Step 5 — Restart Wazuh Manager

\`\`\`bash
sudo systemctl restart wazuh-manager
\`\`\`

Wait ~30 seconds for the manager to fully restart.

## Verification

On the sensor, run the validation script:

\`\`\`bash
sudo bash /opt/rh-pulsar/validate.sh
\`\`\`

Then in Wazuh Dashboard:

1. Go to: **Modules → Security Events**
2. Time range: **Last 15 minutes**
3. Filter: \`rule.groups: rh-pulsar\`

You should see alerts from rules 110001, 110002, 110004, 110005. Rule 110003 requires real Sliver C2 traffic for end-to-end validation.

## Active Response setup (Rule 110003 only)

The active response script must be installed on each SENSOR, not the manager:

\`\`\`bash
# Copy AR script to sensor
scp active-response/rh-pulsar-block.sh sensor:/tmp/

# On the sensor:
ssh sensor
sudo cp /tmp/rh-pulsar-block.sh /var/ossec/active-response/bin/
sudo chown root:wazuh /var/ossec/active-response/bin/rh-pulsar-block.sh
sudo chmod 750        /var/ossec/active-response/bin/rh-pulsar-block.sh
sudo systemctl restart wazuh-agent
\`\`\`

On the manager, ensure the active-response config exists in /var/ossec/etc/ossec.conf:

\`\`\`xml
<command>
  <name>rh-pulsar-block</name>
  <executable>rh-pulsar-block.sh</executable>
  <timeout_allowed>yes</timeout_allowed>
</command>

<active-response>
  <command>rh-pulsar-block</command>
  <location>local</location>
  <rules_id>110003</rules_id>
  <timeout>3600</timeout>
</active-response>
\`\`\`

Restart the manager after adding the config block.

## Need help?

- Full integration guide: see PDF
- Email: support@redhorizon.ph
- Documentation: https://redhorizon.ph/docs/rh-pulsar-for-wazuh

---

Red Horizon · © 2026
EOF
ok "Documentation: INSTALL.md"

# ═══════════════════════════════════════════════════════════
# CHANGELOG.md
# ═══════════════════════════════════════════════════════════
cat > "${PACK_DIR}/CHANGELOG.md" << EOF
# RH Pulsar for Wazuh — Content Pack Changelog

## v${CONTENT_PACK_VER} ($(date +%Y-%m-%d))

Initial public release of RH Pulsar content for Wazuh.

### Decoders

- \`rh-pulsar-zeek\` — base prematch decoder for RH Pulsar log lines
- \`rh-pulsar-zeek-fields\` — JSON field extractor

### Rules

| ID     | Level | MITRE     | Description |
|--------|-------|-----------|-------------|
| 110000 | 3     | —         | Base rule (RH Pulsar notice received) |
| 110001 | 12    | T1071     | C2 Beacon detected |
| 110002 | 14    | T1071.004 | DNS Tunnel detected |
| 110003 | 15    | T1573     | Sliver JA4 detected (triggers active response) |
| 110013 | 14    | T1573     | Malicious JA4 from intel DB |
| 110004 | 12    | T1071.001 | HTTP C2 Beacon |
| 110005 | 10    | T1071.001 | Suspicious User-Agent |
| 110006 | 10    | T1573     | Novel JA4 (Tier 2 baseline) |

### Active Response

- \`rh-pulsar-block.sh\` — iptables-based source IP isolation, configured for Rule 110003 only

### Compatibility

- Sensor product version: ${PRODUCT_VER}
- Wazuh Manager: ${WAZUH_TARGET}
- Tested on: Ubuntu 22.04, Ubuntu 24.04

### Known limitations

- Rule 110005 (Suspicious UA) has ~71% false positive rate in DevOps-heavy environments. Tuning guidance in the Integration Guide.
- Tier 2 baseline (Rule 110006) requires 7-day learning period after sensor deployment before reaching expected accuracy.

---

For older versions, see history at: https://redhorizon.ph/docs/rh-pulsar-for-wazuh/changelog
EOF
ok "Documentation: CHANGELOG.md"

# ═══════════════════════════════════════════════════════════
# README.md (top-level overview)
# ═══════════════════════════════════════════════════════════
cat > "${PACK_DIR}/README.md" << EOF
# RH Pulsar for Wazuh — Content Pack v${CONTENT_PACK_VER}

This content pack adds RH Pulsar detection content to an existing Wazuh Manager.

## What's in this archive

\`\`\`
rh-pulsar-wazuh-content/
├── decoders/
│   └── rh-pulsar-decoders.xml      (parses RH Pulsar JSON notices)
├── rules/
│   └── rh-pulsar-rules.xml         (defines alerts 110000-110006, 110013)
├── active-response/
│   └── rh-pulsar-block.sh          (sensor-side AR script for Rule 110003)
├── examples/
│   ├── sample-notice.log           (example sensor output)
│   └── sample-alert.json           (expected Wazuh alert format)
├── INSTALL.md                      (quick install — 5 steps, 15 min)
├── CHANGELOG.md                    (version history)
└── README.md                       (this file)
\`\`\`

## Getting started

1. Read **INSTALL.md** for quick install steps
2. For complete documentation including tuning and troubleshooting, see the **RH Pulsar for Wazuh — Integration Guide** (PDF, shipped separately)

## Compatibility

| Component         | Version |
|-------------------|---------|
| Content pack      | ${CONTENT_PACK_VER} |
| Sensor product    | ${PRODUCT_VER} |
| Wazuh Manager     | ${WAZUH_TARGET} |

## Support

- Email: support@redhorizon.ph
- Docs:  https://redhorizon.ph/docs/rh-pulsar-for-wazuh

Red Horizon · © 2026
EOF
ok "Documentation: README.md"

# ═══════════════════════════════════════════════════════════
# VALIDATE XML if xmllint available
# ═══════════════════════════════════════════════════════════
# NOTE: Wazuh decoder and rules files traditionally use multiple top-level
# elements without a single root, which is valid for Wazuh's parser but
# not standard XML. We validate by temporarily wrapping in a root element.
validate_wazuh_xml() {
    local file="$1"
    local name="$2"
    local wrapped
    wrapped=$(mktemp)
    {
        echo '<root>'
        cat "$file"
        echo '</root>'
    } > "$wrapped"
    if xmllint --noout "$wrapped" 2>/dev/null; then
        ok "${name}: valid XML"
        rm -f "$wrapped"
        return 0
    else
        fail "${name}: invalid XML"
        echo "  xmllint output:"
        xmllint --noout "$wrapped" 2>&1 | sed 's/^/    /' | head -5
        rm -f "$wrapped"
        return 1
    fi
}

if [[ "$CHECK_ONLY" == "true" ]] || command -v xmllint &>/dev/null; then
    echo ""
    echo -e "${W}  Validating XML...${N}"
    if command -v xmllint &>/dev/null; then
        validate_wazuh_xml "${PACK_DIR}/decoders/rh-pulsar-decoders.xml" "decoders/rh-pulsar-decoders.xml" || exit 1
        validate_wazuh_xml "${PACK_DIR}/rules/rh-pulsar-rules.xml" "rules/rh-pulsar-rules.xml" || exit 1
    else
        info "xmllint not installed - skipping XML validation"
    fi
fi

if [[ "$CHECK_ONLY" == "true" ]]; then
    echo ""
    ok "Check passed - no archive created (use without --check to build)"
    exit 0
fi

# ═══════════════════════════════════════════════════════════
# BUILD ARCHIVE
# ═══════════════════════════════════════════════════════════
echo ""
echo -e "${W}  Building archive...${N}"

# Set sane file permissions before archiving
find "$PACK_DIR" -type d -exec chmod 755 {} \;
find "$PACK_DIR" -type f -exec chmod 644 {} \;
chmod 755 "${PACK_DIR}/active-response/rh-pulsar-block.sh"

tar -czf "$TGZ_OUT" -C "$WORK_ROOT" "$PACK_NAME"
ok "Archive: $TGZ_OUT"

# Calculate SHA256
sha256sum "$TGZ_OUT" | awk '{print $1}' > "$SHA_OUT"
ok "Checksum: $SHA_OUT"

# ═══════════════════════════════════════════════════════════
# SUMMARY
# ═══════════════════════════════════════════════════════════
echo ""
echo -e "${G}  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo -e "${G}  Content pack built successfully${N}"
echo -e "${G}  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${N}"
echo ""
echo -e "  Archive:  ${W}${TGZ_OUT}${N}"
echo -e "  Checksum: ${W}${SHA_OUT}${N}"
echo -e "  Size:     ${W}$(du -h "$TGZ_OUT" | cut -f1)${N}"
echo -e "  SHA256:   ${W}$(cat "$SHA_OUT")${N}"
echo ""
echo "  To distribute to a client engineer:"
echo "    1. Send: $TGZ_OUT"
echo "    2. Send: $SHA_OUT (for integrity verification)"
echo "    3. Send: 'RH Pulsar for Wazuh - Integration Guide.pdf' (full docs)"
echo ""
echo "  Client engineer verifies:"
echo "    sha256sum -c <(echo \"\$(cat ${PACK_NAME}-v${CONTENT_PACK_VER}.sha256)  ${PACK_NAME}-v${CONTENT_PACK_VER}.tgz\")"
echo ""
